
package Assignment2;

import java.util.Arrays;
import java.util.Scanner;

public class FarmMain {

    private static final int ACQUIRE_ANIMAL = 1;
    private static final int PRINT_ANIMALS = 2;
    private static final int PRINT_CHEAPEST_ANIMAL = 3;
    private static final int PRINT_ANIMAL = 4;
    private static final int ANIMAL_WANDER = 5;
    private static final int HIRE_FARMER = 6;
    private static final int FEED_ANIMAL = 7;
    private static final int QUIT = 8;

    private Animal[] animals;
    private Farmer[] farmers;
    private int acquiredAnimals; // declaring the variable
    private int hiredFarmers;// declaring the variable

    private Scanner input;

    /*
     * Constructor to initialize your data set of animals and farmers. It begins
     * empty. The default size is 5 animals and 5 farmers.
     */

    public FarmMain() {
        final int INITIAL_BARN_SIZE = 5;
        this.animals = new Animal[INITIAL_BARN_SIZE]; // this is the size of the barn in which the first set of animals
        // can be housed
        this.acquiredAnimals = 0;

        final int INITIAL_HOUSE_SIZE = 5;
        this.farmers = new Farmer[INITIAL_HOUSE_SIZE]; // this is the size of the house in which the first set of
        // farmers can live
        this.hiredFarmers = 0;
        input = new Scanner(System.in);
    }

    /*
     * This method will retrieve an animal from the array based on a specified name.
     * If the animal was not created and added to the array, it will return NULL,
     * meaning that the animal does not exist in the system.
     *
     */
    public Animal retrieveAnimal(String animalName) {
        for (int i = 0; i < this.animals.length; i++) {
            if ((!animals[i].equals(null)) && (animals[i].getName()).equals(animalName)) {
                return animals[i];
            }
        }
        /*
         * example of a null... if no animal with the give name exists, the object does
         * not exist (i.e. "nothing").
         */
        return null;
    }

    /*
     * This method will retrieve a farmer from the array based on a specified name.
     * If the farmer was not created and added to the array, it should return NULL,
     * meaning that the farmer does not exist in the system.
     *
     */
    public Farmer retrieveFarmer(String farmerName) {
        for (int i = 0; i < this.farmers.length; i++) {
            if ((!farmers[i].equals(null)) && (farmers[i].getName()).equals(farmerName)) {
                return farmers[i];
            }
        }
        /*
         * example of a null... if no animal with the give name exists, the object does
         * not exist (i.e. "nothing").
         */
        return null;
    }

    /*
     * This method allows the user to create the animal. Either create an animal
     * with a default Hunger level 1, or create an animal with a custom animal.
     */
    public Animal createAnimal() {

        System.out.print("What is the animals name? ");
        String name = input.nextLine();

        System.out.print("What animal would you like? (Chicken/Cow/Sheep): ");
        String animalType = input.nextLine();

        System.out.print("How much does it weigh? ");
        int weight = input.nextInt();
            input.nextLine();

        System.out.print("How old is " + name + "? ");
        int age = input.nextInt();
            input.nextLine();

        System.out.print("How hungry is " + name + "? ");
        double hunger = input.nextDouble();

        return new Animal(name, animalType, weight, age, hunger);
    }

    public Farmer createFarmer() {

        System.out.println("What is the farmers name? ");
        String name = input.nextLine();
        return new Farmer(name);
    }

    public void run() {

        int option;
        do {
            printMenuOptions();
            System.out.print(" Type the option number: ");
            option = input.nextInt();
            input.nextLine(); // this skips the enter
            // that the user types after
            // typing the integer option.

            switch (option) {
                case ACQUIRE_ANIMAL:

                    Animal newAnimal = createAnimal();
                    if (acquiredAnimals<5) {
                    	System.out.println("no more than 5");
                    	animals[acquiredAnimals]=newAnimal;
                    }
                    else {
                    	System.out.println("more than 5");
                    	Animal[] animals1=new Animal[acquiredAnimals+1];
            			for(int i=0;i<acquiredAnimals;i++) {
            				animals1[i]=this.animals[i];
            			}
            			animals1[acquiredAnimals]=newAnimal;
            			this.animals=animals1;
                    }
                    this.acquiredAnimals = this.acquiredAnimals + 1;
                    // Make sure your program allows any amount of animals!
                    // Assume that we can add more than 5 animals to the array.
                    //
                    break;

                case PRINT_ANIMALS:
                    printAllAnimals();
                    break;

                case PRINT_ANIMAL:
                    printOneAnimal();
                    break;

                case PRINT_CHEAPEST_ANIMAL:
                    printCheapest();
                    break;

                case ANIMAL_WANDER:
                    wander();
                    break;

                case HIRE_FARMER:
                    Farmer newFarmer = createFarmer();
                    this.farmers[hiredFarmers] = newFarmer;
                    this.hiredFarmers = this.hiredFarmers + 1;
                    // Make sure your program allows any amount of farmers!
                    // Assume that we can add more than 5 farmers to the array.
                    break;

                case FEED_ANIMAL:
                    feed();
                    break;

                case QUIT:
                    System.out.println("Thank you for visiting our Barn. See you soon!");
                    System.out.println();
                    break;

                default:
                    System.out.println("Option " + option + " is not valid.");
                    System.out.println();
                    break;
            }
        } while (option != QUIT);
    }

    // This method is private because it should be used only by
    // this class since the menu is specific to this main.
    private void printMenuOptions() {
        System.out.println(" === Welcome to DIT042 Barn === ");
        System.out.println(" Choose an option below: ");
        System.out.println(" ");
        System.out.println(" 1. Acquire an animal. ");
        System.out.println(" 2. Print all animals. ");
        System.out.println(" 3. Print the cheapest animal's information. ");
        System.out.println(" 4. Print an animal's information. ");
        System.out.println(" 5. Make an animal wander ");
        System.out.println(" 6. Hire a farmer ");
        System.out.println(" 7. Feed an animal ");
        System.out.println(" 8. Quit this program. ");
        System.out.println();
    }

    public void printAllAnimals() {
        // TODO: Add the code for the logic below
        // 1. Iterate through all animals and print each one of them
        // if they are not null!
        // BE CAREFUL! avoid printing nulls by checking:
        // if( animals[i] != null ) { ... print it ... }
        for (int i = 0; i < animals.length; i++){
            if (!animals[i].getName().equals(null)){
                System.out.println(animals[i].getName());
            }
        }//!null.equals(animals[i].getName())
    }

    public void printOneAnimal() {
        String animalName = readName("Type in the name of the animal: ");

        Animal foundAnimal = retrieveAnimal(animalName);
        // TODO: Add the code for the logic below
        // 1. Print the found animal, according to assignment's format (Task 2)
        // 2. Remember that the animal may not exist, so...
        // print only if the foundAnimal is NOT null.
    }

    public void printCheapest() {
        // TODO: Add the code for the logic below
        // 1. ask for the animal's type
        // 2. Iterate through all animals to get the ones with the type specified
        // 3. Iterate through all the animals with this type and find the one with the
        // lowest price
        // 4. Print the found (cheapest) animal
        // BE CAREFUL! avoid printing nulls by checking:
        // if( animals[i] != null ) { ... print it ... }
    }

    /*
     * This method is used whenever you want to read a String, so it's reusable for
     * reading both the farmer and animal's names.
     * You should specify as parameter the message shown to the user.
     */
    public String readName(String userMessage) {
        System.out.print(userMessage);
        String name = input.nextLine();
        return name;
    }

    /*
     * This method is used for reading any integer number. Therefore, it can be reused
     *  for reading the number of laps when an animal wanders, or the amount of kilos
     *  the farmer will feed an animal.
     * You must specify the message shown to the user.
     */
    //"Type the integer amound of food in kg: "
    public int readIntNumber(String userMessage) {
        System.out.print(userMessage);
        int foodAmount = input.nextInt();
        input.nextLine();
        return foodAmount;
    }

    /*
     * This method is used for reading any double number. Therefore, it can be reused
     *  for reading the weight and the hunger level when creating animals. Remember to
     *  check your language settings for using comma (,) or dot (.) as a decimal separator.
     * You must specify the message shown to the user.
     */
    //"Type the integer amound of food in kg: "
    public double readDoubleNumber(String userMessage) {
        System.out.print(userMessage);
        double doubleNumber = input.nextDouble();
        input.nextLine();
        return doubleNumber;
    }

    public void wander() {
        String animalName = readName("Type the name of the animal that should wander: ");
        Animal foundAnimal = retrieveAnimal(animalName);
        if (!foundAnimal.equals(null)) {
        System.out.println("How many laps does it wander? ");
        double lap=input.nextDouble();
        input.nextLine();
        if (lap > 0 && foundAnimal.getHunger() < 1) {

            double hunger = foundAnimal.getHunger() + 0.1 * lap;
            double weight =foundAnimal.getWeight() - lap;

            foundAnimal.setHunger(hunger);
            foundAnimal.setWeight(weight);
            System.out.println(foundAnimal.getName()+" new hunger level is "+foundAnimal.getHunger());
           
        }else if(lap < 0){
            System.out.println("Error: " + foundAnimal.getName() + "can't run a negative amount of laps.");
        }else{
        	foundAnimal.setWeight(0);
        }
    }
        else {
        	System.out.println(animalName+" is not registered");
        }
        
   

		// TODO: write code for the following logic:
        // 1. Read a double value for the amount of laps to wander.
        // 2. If the animal was really found, wander(i.e. increase the hunger level of
        // the animal) it.
        // 3. Print the message: "<animal_name> new hunger level is
        // <animal_hunger_level>"
        // 4. Remember to not allow the animal to wander negative minutes.
    }

    public void feed() {
        String animalName = readName("Type the name of the animal to be fed:");
        Animal foundAnimal = retrieveAnimal(animalName);
        String farmerName = readName("Type the name of the farmer that should feed it: ");
        Farmer foundFarmer = retrieveFarmer(farmerName);
        int foodAmount = readIntNumber("How many kilos of food will "+foundAnimal.getName()+" eat:");
        
        // TODO: write code for the following logic:
        // 1. Read the animal name and check if it exists. (done already above)
        // 2. Read the farmer name and check if they exist. (done already above)
        // 3. Read the amount of food. (done already above)
        if (animalName.equals(null)) {
        	System.out.print("Error: Animal is not registered");}
        

        else if (farmerName.equals(null)) {
            System.out.print("Error: Farmer is not registered");
        }else if (foundAnimal.getHunger()==0) {
        	System.out.print("Error when feeding the animal"+ foundAnimal.getName()+ "they are already full");}
        else if (foundAnimal.getHunger()-0.05*foodAmount>0){
        	System.out.print(foundAnimal.getName()+" successfully feeded by "+foundAnimal.getName() +foundAnimal.getName()+" hunger level is "+(foundAnimal.getHunger()-0.05*foodAmount));}
        else {
        	System.out.print(foundAnimal.getName()+" successfully feeded by "+foundAnimal.getName() +foundAnimal.getName()+" hunger level is "+0);
        }
        // 4. Make the farmer feed the animal, as specified in the task.
        // 5. Print the message: "<animal_name> new weight is <weight> and hunger level
        // is <hunger_level>"
        
    }

    public static void main(String[] args) {
        FarmMain program = new FarmMain();
        program.run();
    }
}

